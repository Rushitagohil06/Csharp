﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            object obj = i;
            Console.WriteLine(i);
            int j = (int)obj;
            Console.WriteLine(j);
            Console.Read();
        }
    }
}
