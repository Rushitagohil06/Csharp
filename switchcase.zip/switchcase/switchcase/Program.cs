﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switchcase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter 1 for black bg:");
            Console.Write("enter 2 for white bg:");
            Console.Write("enter 3 for blue bg:");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    break;

                case 2:
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;

                case 3:
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;

                default:
                    Console.Write("enter correct num:");
                    break;
            }
            Console.ReadLine();
        }
    }
}
